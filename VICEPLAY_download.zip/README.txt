VICEPLAY starter website

Files:
- index.html: the complete mobile-friendly site.

Preview:
Open index.html in a browser.

Publish for free:
1. Create a GitHub account if you don't already have one.
2. Create a new public repository named viceplay.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select main and /(root), then Save.
7. Wait for GitHub Pages to publish the site.

Notes:
- Search, category filters, favorites, and recently opened games work in the page.
- Favorites and recently opened games are saved in that browser on that device.
- Game links open publisher/hosting pages. They are not embedded copies.
- Plants vs. Zombies and Geometry Dash are currently listed as information links, not verified playable browser embeds.
- The site is an independent fan-made directory and is not affiliated with Rockstar Games.
